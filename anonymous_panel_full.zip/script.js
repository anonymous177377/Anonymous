/* script.js - behavior for the panel */

const CORRECT_USER = "RickAlves76";
const CORRECT_PASS = "04052023";

let failedAttempts = 0;
let lockTimeout = null;
let lockActive = false;

// DOM
const loginScreen = document.getElementById('login-screen');
const loginInputs = document.getElementById('login-inputs');
const loginField = document.getElementById('login');
const passField = document.getElementById('senha');
const enterBtn = document.getElementById('enterBtn');
const demoBtn = document.getElementById('demoBtn');
const accessScreen = document.getElementById('access-screen');
const panel = document.getElementById('panel');
const matrixCanvas = document.getElementById('matrix');

// Audio
const clickSound = document.getElementById('click-sound');
const loginSound = document.getElementById('login-sound');
const deniedSound = document.getElementById('denied-sound');
const lockSound = document.getElementById('lock-sound');
const introVoice = document.getElementById('intro-voice');


// Show inputs after typewriter animation
window.addEventListener('load', () => {
  setTimeout(()=> {
    loginInputs.style.opacity = 1;
  }, 2400);

  // Play intro voice automatically (may be blocked by browsers)
  setTimeout(()=> {
    try { introVoice.play(); } catch(e) { /* ignore */ }
  }, 500);
});

// Demo fill button
demoBtn.addEventListener('click', ()=> {
  loginField.value = CORRECT_USER;
  passField.value = CORRECT_PASS;
});

// ENTER button
enterBtn.addEventListener('click', doLogin);

// also allow Enter key in fields
[loginField, passField].forEach(f => f.addEventListener('keydown', e => {
  if(e.key === 'Enter') doLogin();
}));

function doLogin(){
  if(lockActive) return;
  const u = loginField.value.trim();
  const p = passField.value.trim();

  if(failedAttempts >= 3){
    triggerLock();
    return;
  }

  if(u === CORRECT_USER && p === CORRECT_PASS){
    successLogin();
  } else {
    failedAttempts++;
    triggerDenied();
    if(failedAttempts >= 3){
      // next attempt will show lock; we'll still allow immediate lock here
      setTimeout(()=> triggerLock(), 800);
    }
  }
}

function successLogin(){
  try{ loginSound.play(); }catch(e){}
  // show authorized overlay briefly, then show panel
  accessScreen.style.display = 'flex';
  setTimeout(()=> {
    accessScreen.style.display = 'none';
    panel.style.display = 'block';
    panel.setAttribute('aria-hidden','false');
    // show default tab
    openTab('aba1');
  }, 1400);
}

// ACCESS DENIED animation + sound
function triggerDenied(){
  const denied = document.createElement('div');
  denied.id = 'accessDenied';
  denied.innerHTML = '<div class="denied-box">ACESSO NEGADO</div>';
  document.body.appendChild(denied);
  try{ deniedSound.play(); }catch(e){}
  // shake screen effect handled by CSS animation on #accessDenied
  setTimeout(()=> {
    denied.remove();
  }, 1800);
}

// LOCK screen after 3 fails
function triggerLock(){
  lockActive = true;
  const lock = document.createElement('div');
  lock.id = 'lockScreen';
  lock.innerHTML = '<div class="lock-box">SISTEMA BLOQUEADO<br>AGUARDE 30 SEGUNDOS</div>';
  document.body.appendChild(lock);
  try{ lockSound.play(); }catch(e){}
  // disable inputs visually
  loginField.disabled = true;
  passField.disabled = true;
  enterBtn.disabled = true;
  demoBtn.disabled = true;

  lockTimeout = setTimeout(()=> {
    lock.remove();
    failedAttempts = 0;
    lockActive = false;
    loginField.disabled = false;
    passField.disabled = false;
    enterBtn.disabled = false;
    demoBtn.disabled = false;
  }, 30000);
}

// NAV links and buttons
document.getElementById('openVex').addEventListener('click', ()=> {
  try{ clickSound.play(); }catch(e){}
  window.location.href = 'https://www.vexpainel.com/consultar/';
});
document.getElementById('vexLink').addEventListener('click', ()=> {
  try{ clickSound.play(); }catch(e){}
  window.location.href = 'https://www.vexpainel.com/consultar/';
});

// Tabs
document.querySelectorAll('.tab-btn').forEach(btn=>{
  btn.addEventListener('click', ()=> {
    const id = btn.getAttribute('data-tab');
    openTab(id);
  });
});
function openTab(id){
  document.querySelectorAll('.tab-page').forEach(p=> p.style.display='none');
  const page = document.getElementById(id);
  if(page) page.style.display='block';
  try{ clickSound.play(); }catch(e){}
}

// Terminal basic
const terminal = document.getElementById('terminal');
const terminalInput = document.getElementById('terminal-input');
document.getElementById('toggleTerminal').addEventListener('click', ()=> {
  openTab('aba2');
});
terminalInput.addEventListener('keydown', (e)=> {
  if(e.key === 'Enter'){
    const txt = terminalInput.value.trim();
    appendTerminal('> ' + txt);
    if(txt === 'help') appendTerminal('Comandos: help, data, clear, about');
    else if(txt === 'data') appendTerminal(new Date().toString());
    else if(txt === 'clear') terminal.innerHTML = '';
    else if(txt === 'about') appendTerminal('Painel Hacker - Demo');
    else appendTerminal('Comando não encontrado: ' + txt);
    terminalInput.value = '';
    terminal.scrollTop = terminal.scrollHeight;
  }
});
function appendTerminal(t){ const d = document.createElement('div'); d.textContent = t; terminal.appendChild(d); }

// Themes buttons
document.querySelectorAll('[data-theme]').forEach(b=>{
  b.addEventListener('click', ()=> {
    const t = b.getAttribute('data-theme');
    if(t==='green') document.documentElement.style.setProperty('--neon-green','#0f0');
    if(t==='blue') document.documentElement.style.setProperty('--neon-green','#0ff');
    if(t==='red') document.documentElement.style.setProperty('--neon-green','#ff2a2a');
  });
});

// MATRIX effect
(function matrix(){
  const canvas = matrixCanvas;
  const ctx = canvas.getContext('2d');
  const setSize = ()=> { canvas.width = innerWidth; canvas.height = innerHeight; }
  setSize(); window.addEventListener('resize', setSize);
  const letters = '01TXHZ34ABCDE'.split('');
  const fontSize = 14;
  const columns = Math.floor(canvas.width / fontSize);
  const drops = Array(columns).fill(1);
  function draw(){
    ctx.fillStyle = 'rgba(0,0,0,0.06)';
    ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--neon-green') || '#0f0';
    ctx.font = fontSize + 'px monospace';
    for(let i=0;i<drops.length;i++){
      const text = letters[Math.floor(Math.random()*letters.length)];
      ctx.fillText(text, i*fontSize, drops[i]*fontSize);
      if(drops[i]*fontSize > canvas.height && Math.random() > 0.975) drops[i] = 0;
      drops[i]++;
    }
  }
  setInterval(draw, 40);
})();

// Remove intro after animation (video may be shorter - still remove)
setTimeout(()=> {
  const intro = document.getElementById('anonymous-intro');
  if(intro) intro.remove();
  // show login screen inputs (if not already)
  loginInputs.style.opacity = 1;
}, 4800);
