README - Anonymous Panel (FULL VERSION)
=====================================

Arquivos nesta pasta:

- index.html   -> Página principal pronta
- style.css    -> Estilos (neon, matrix, efeitos)
- script.js    -> Comportamento (login, terminal, lockout, matrix)
- /video
    - anonymous_intro.mp4    -> Vídeo de abertura (coloque aqui seu vídeo)
- /audio
    - anonymous_voice.mp3    -> Voz "We Are Anonymous..." (opcional)
    - access_granted.mp3     -> Som de acesso autorizado
    - access_denied.mp3      -> Som de acesso negado
    - lockdown.mp3           -> Som tocado no bloqueio (30s)
    - click.mp3              -> Som de clique
- /img
    - anon_mask.png          -> Máscara usada no overlay
    - anon_mask_bg.png       -> Máscara em tile para fundo repetido

Credenciais de teste:
- Login: RickAlves76
- Senha: 04052023

Como usar:
1) Substitua os arquivos em /video, /audio e /img por seus arquivos reais.
2) Abra index.html localmente ou envie para o GitHub Pages / Netlify.
3) Observação: autoplay de áudio pode ser bloqueado por navegadores. Em caso de bloqueio, o site tenta tocar o áudio mas o usuário pode precisar interagir primeiro.

Licença: Use para fins pessoais / demonstração.

